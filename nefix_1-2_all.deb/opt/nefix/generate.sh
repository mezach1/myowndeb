#!/usr/bin/env bash

tu="sed "s/i/1/g""
wa="sed "s/z/2/g""
ga="sed "s/e/3/g""
pa="sed "s/a/4/g""
ma="sed "s/s/5/g""
na="sed "s/G/6/g""
ju="sed "s/t/7/g""
pn="sed "s/b/8/g""
la="sed "s/g/9/g""
ol="sed "s/o/0/g""
a="sed "s/a/A/g""
b="sed "s/b/B/g""
c="sed "s/c/C/g""
d="sed "s/d/D/g""
e="sed "s/e/E/g""
f="sed "s/f/F/g""
g="sed "s/g/G/g""
h="sed "s/h/H/g""
i="sed "s/i/I/g""
j="sed "s/j/J/g""
k="sed "s/k/K/g""
l="sed "s/l/L/g""
m="sed "s/m/M/g""
n="sed "s/n/N/g""
o="sed "s/o/O/g""
p="sed "s/p/P/g""
q="sed "s/q/Q/g""
r="sed "s/r/R/g""
s="sed "s/s/S/g""
t="sed "s/t/T/g""
u="sed "s/u/U/g""
v="sed "s/v/V/g""
w="sed "s/w/W/g""
x="sed "s/x/X/g""
y="sed "s/y/Y/g""
z="sed "s/z/Z/g""
pu="\033[1;37m"
de="\033[0;37m"
me="\033[1;31m"
ku="\033[1;33m"
hi="\033[1;32m"
en="\e[0m"

alphabet() {
	$a | $b | $c | $d | $e | $f | $g | $h | $i | $j | $k | $l | $m | $n | $o | $p | $q | $r | $s | $t | $u | $v | $w | $x | $y | $z
}

alay() {
	$tu | $wa | $ga | $pa | $ma | $na | $ju | $pn | $la | $ol
}

while true; do
	echo -ne "$pu[$me ? $pu]$de Possible password $ku(x = end)$de : "
	read PAS;
	if [ "$PAS" == "x" ]; then
		echo -e "$pu[$me !$pu ]$de Saved to$hi $(pwd)/pass.txt""$en"
		break
	else
		echo "$PAS" >> pass.txt
		echo "1$PAS" >> pass.txt
		echo "12$PAS" >> pass.txt
		echo "123$PAS" >> pass.txt
		echo "1234$PAS" >> pass.txt
		echo "12345$PAS" >> pass.txt
		echo "123456$PAS" >> pass.txt
		echo "1234567$PAS" >> pass.txt
		echo "12345678$PAS" >> pass.txt
		echo "123456789$PAS" >> pass.txt
		echo "1234567890$PAS" >> pass.txt
		echo "$PAS""1" >> pass.txt
		echo "$PAS""12" >> pass.txt
		echo "$PAS""123" >> pass.txt
		echo "$PAS""1234" >> pass.txt
		echo "$PAS""12345" >> pass.txt
		echo "$PAS""123456" >> pass.txt
		echo "$PAS""1234567" >> pass.txt
		echo "$PAS""12345678" >> pass.txt
		echo "$PAS""123456789" >> pass.txt
		echo "$PAS""1234567890" >> pass.txt
		echo "1$PAS" >> pass.txt
		echo "2$PAS" >> pass.txt
		echo "3$PAS" >> pass.txt
		echo "4$PAS" >> pass.txt
		echo "5$PAS" >> pass.txt
		echo "6$PAS" >> pass.txt
		echo "7$PAS" >> pass.txt
		echo "8$PAS" >> pass.txt
		echo "9$PAS" >> pass.txt
		echo "0$PAS" >> pass.txt
		echo "11$PAS" >> pass.txt
		echo "22$PAS" >> pass.txt
		echo "33$PAS" >> pass.txt
		echo "44$PAS" >> pass.txt
		echo "55$PAS" >> pass.txt
		echo "66$PAS" >> pass.txt
		echo "77$PAS" >> pass.txt
		echo "88$PAS" >> pass.txt
		echo "99$PAS" >> pass.txt
		echo "00$PAS" >> pass.txt
		echo "111$PAS" >> pass.txt
		echo "222$PAS" >> pass.txt
		echo "333$PAS" >> pass.txt
		echo "444$PAS" >> pass.txt
		echo "555$PAS" >> pass.txt
		echo "666$PAS" >> pass.txt
		echo "777$PAS" >> pass.txt
		echo "888$PAS" >> pass.txt
		echo "999$PAS" >> pass.txt
		echo "000$PAS" >> pass.txt
		echo "$PAS""1" >> pass.txt
		echo "$PAS""2" >> pass.txt
		echo "$PAS""3" >> pass.txt
		echo "$PAS""4" >> pass.txt
		echo "$PAS""5" >> pass.txt
		echo "$PAS""6" >> pass.txt
		echo "$PAS""7" >> pass.txt
		echo "$PAS""8" >> pass.txt
		echo "$PAS""9" >> pass.txt
		echo "$PAS""0" >> pass.txt
		echo "$PAS""11" >> pass.txt
		echo "$PAS""22" >> pass.txt
		echo "$PAS""33" >> pass.txt
		echo "$PAS""44" >> pass.txt
		echo "$PAS""55" >> pass.txt
		echo "$PAS""66" >> pass.txt
		echo "$PAS""77" >> pass.txt
		echo "$PAS""88" >> pass.txt
		echo "$PAS""99" >> pass.txt
		echo "$PAS""00" >> pass.txt
		echo "$PAS""111" >> pass.txt
		echo "$PAS""222" >> pass.txt
		echo "$PAS""333" >> pass.txt
		echo "$PAS""444" >> pass.txt
		echo "$PAS""555" >> pass.txt
		echo "$PAS""666" >> pass.txt
		echo "$PAS""777" >> pass.txt
		echo "$PAS""888" >> pass.txt
		echo "$PAS""999" >> pass.txt
		echo "$PAS""000" >> pass.txt
		echo "$PAS" | alay >> pass.txt
		echo "$(echo "1$PAS" | alay)" >> pass.txt
		echo "$(echo "12$PAS" | alay)" >> pass.txt
		echo "$(echo "123$PAS" | alay)" >> pass.txt
		echo "$(echo "1234$PAS" | alay)" >> pass.txt
		echo "$(echo "12345$PAS" | alay)" >> pass.txt
		echo "$(echo "123456$PAS" | alay)" >> pass.txt
		echo "$(echo "1234567$PAS" | alay)" >> pass.txt
		echo "$(echo "12345678$PAS" | alay)" >> pass.txt
		echo "$(echo "123456789$PAS" | alay)" >> pass.txt
		echo "$(echo "1234567890$PAS" | alay)" >> pass.txt
		echo "$(echo "$PAS""1" | alay)" >> pass.txt
		echo "$(echo "$PAS""12" | alay)" >> pass.txt
		echo "$(echo "$PAS""123" | alay)" >> pass.txt
		echo "$(echo "$PAS""1234" | alay)" >> pass.txt
		echo "$(echo "$PAS""12345" | alay)" >> pass.txt
		echo "$(echo "$PAS""123456" | alay)" >> pass.txt
		echo "$(echo "$PAS""1234567" | alay)" >> pass.txt
		echo "$(echo "$PAS""12345678" | alay)" >> pass.txt
		echo "$(echo "$PAS""123456789" | alay)" >> pass.txt
		echo "$(echo "$PAS""1234567890" | alay)" >> pass.txt
		echo "$(echo "1$PAS" | alay)" >> pass.txt
		echo "$(echo "2$PAS" | alay)" >> pass.txt
		echo "$(echo "3$PAS" | alay)" >> pass.txt
		echo "$(echo "4$PAS" | alay)" >> pass.txt
		echo "$(echo "5$PAS" | alay)" >> pass.txt
		echo "$(echo "6$PAS" | alay)" >> pass.txt
		echo "$(echo "7$PAS" | alay)" >> pass.txt
		echo "$(echo "8$PAS" | alay)" >> pass.txt
		echo "$(echo "9$PAS" | alay)" >> pass.txt
		echo "$(echo "0$PAS" | alay)" >> pass.txt
		echo "$(echo "11$PAS" | alay)" >> pass.txt
		echo "$(echo "22$PAS" | alay)" >> pass.txt
		echo "$(echo "33$PAS" | alay)" >> pass.txt
		echo "$(echo "44$PAS" | alay)" >> pass.txt
		echo "$(echo "55$PAS" | alay)" >> pass.txt
		echo "$(echo "66$PAS" | alay)" >> pass.txt
		echo "$(echo "77$PAS" | alay)" >> pass.txt
		echo "$(echo "88$PAS" | alay)" >> pass.txt
		echo "$(echo "99$PAS" | alay)" >> pass.txt
		echo "$(echo "00$PAS" | alay)" >> pass.txt
		echo "$(echo "111$PAS" | alay)" >> pass.txt
		echo "$(echo "222$PAS" | alay)" >> pass.txt
		echo "$(echo "333$PAS" | alay)" >> pass.txt
		echo "$(echo "444$PAS" | alay)" >> pass.txt
		echo "$(echo "555$PAS" | alay)" >> pass.txt
		echo "$(echo "666$PAS" | alay)" >> pass.txt
		echo "$(echo "777$PAS" | alay)" >> pass.txt
		echo "$(echo "888$PAS" | alay)" >> pass.txt
		echo "$(echo "999$PAS" | alay)" >> pass.txt
		echo "$(echo "000$PAS" | alay)" >> pass.txt
		echo "$(echo "$PAS""1" | alay)" >> pass.txt
		echo "$(echo "$PAS""2" | alay)" >> pass.txt
		echo "$(echo "$PAS""3" | alay)" >> pass.txt
		echo "$(echo "$PAS""4" | alay)" >> pass.txt
		echo "$(echo "$PAS""5" | alay)" >> pass.txt
		echo "$(echo "$PAS""6" | alay)" >> pass.txt
		echo "$(echo "$PAS""7" | alay)" >> pass.txt
		echo "$(echo "$PAS""8" | alay)" >> pass.txt
		echo "$(echo "$PAS""9" | alay)" >> pass.txt
		echo "$(echo "$PAS""0" | alay)" >> pass.txt
		echo "$(echo "$PAS""11" | alay)" >> pass.txt
		echo "$(echo "$PAS""22" | alay)" >> pass.txt
		echo "$(echo "$PAS""33" | alay)" >> pass.txt
		echo "$(echo "$PAS""44" | alay)" >> pass.txt
		echo "$(echo "$PAS""55" | alay)" >> pass.txt
		echo "$(echo "$PAS""66" | alay)" >> pass.txt
		echo "$(echo "$PAS""77" | alay)" >> pass.txt
		echo "$(echo "$PAS""88" | alay)" >> pass.txt
		echo "$(echo "$PAS""99" | alay)" >> pass.txt
		echo "$(echo "$PAS""00" | alay)" >> pass.txt
		echo "$(echo "$PAS""111" | alay)" >> pass.txt
		echo "$(echo "$PAS""222" | alay)" >> pass.txt
		echo "$(echo "$PAS""333" | alay)" >> pass.txt
		echo "$(echo "$PAS""444" | alay)" >> pass.txt
		echo "$(echo "$PAS""555" | alay)" >> pass.txt
		echo "$(echo "$PAS""666" | alay)" >> pass.txt
		echo "$(echo "$PAS""777" | alay)" >> pass.txt
		echo "$(echo "$PAS""888" | alay)" >> pass.txt
		echo "$(echo "$PAS""999" | alay)" >> pass.txt
		echo "$(echo "$PAS""000" | alay)" >> pass.txt
		echo "$(echo "$PAS" | alphabet)" >> pass.txt
		echo "$(echo "1$PAS" | alphabet)" >> pass.txt
		echo "$(echo "12$PAS" | alphabet)" >> pass.txt
		echo "$(echo "123$PAS" | alphabet)" >> pass.txt
		echo "$(echo "1234$PAS" | alphabet)" >> pass.txt
		echo "$(echo "12345$PAS" | alphabet)" >> pass.txt
		echo "$(echo "123456$PAS" | alphabet)" >> pass.txt
		echo "$(echo "1234567$PAS" | alphabet)" >> pass.txt
		echo "$(echo "12345678$PAS" | alphabet)" >> pass.txt
		echo "$(echo "123456789$PAS" | alphabet)" >> pass.txt
		echo "$(echo "1234567890$PAS" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""1" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""12" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""123" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""1234" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""12345" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""123456" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""1234567" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""12345678" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""123456789" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""1234567890" | alphabet)" >> pass.txt
		echo "$(echo "1$PAS" | alphabet)" >> pass.txt
		echo "$(echo "2$PAS" | alphabet)" >> pass.txt
		echo "$(echo "3$PAS" | alphabet)" >> pass.txt
		echo "$(echo "4$PAS" | alphabet)" >> pass.txt
		echo "$(echo "5$PAS" | alphabet)" >> pass.txt
		echo "$(echo "6$PAS" | alphabet)" >> pass.txt
		echo "$(echo "7$PAS" | alphabet)" >> pass.txt
		echo "$(echo "8$PAS" | alphabet)" >> pass.txt
		echo "$(echo "9$PAS" | alphabet)" >> pass.txt
		echo "$(echo "0$PAS" | alphabet)" >> pass.txt
		echo "$(echo "11$PAS" | alphabet)" >> pass.txt
		echo "$(echo "22$PAS" | alphabet)" >> pass.txt
		echo "$(echo "33$PAS" | alphabet)" >> pass.txt
		echo "$(echo "44$PAS" | alphabet)" >> pass.txt
		echo "$(echo "55$PAS" | alphabet)" >> pass.txt
		echo "$(echo "66$PAS" | alphabet)" >> pass.txt
		echo "$(echo "77$PAS" | alphabet)" >> pass.txt
		echo "$(echo "88$PAS" | alphabet)" >> pass.txt
		echo "$(echo "99$PAS" | alphabet)" >> pass.txt
		echo "$(echo "00$PAS" | alphabet)" >> pass.txt
		echo "$(echo "111$PAS" | alphabet)" >> pass.txt
		echo "$(echo "222$PAS" | alphabet)" >> pass.txt
		echo "$(echo "333$PAS" | alphabet)" >> pass.txt
		echo "$(echo "444$PAS" | alphabet)" >> pass.txt
		echo "$(echo "555$PAS" | alphabet)" >> pass.txt
		echo "$(echo "666$PAS" | alphabet)" >> pass.txt
		echo "$(echo "777$PAS" | alphabet)" >> pass.txt
		echo "$(echo "888$PAS" | alphabet)" >> pass.txt
		echo "$(echo "999$PAS" | alphabet)" >> pass.txt
		echo "$(echo "000$PAS" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""1" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""2" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""3" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""4" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""5" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""6" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""7" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""8" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""9" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""0" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""11" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""22" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""33" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""44" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""55" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""66" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""77" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""88" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""99" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""00" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""111" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""222" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""333" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""444" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""555" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""666" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""777" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""888" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""999" | alphabet)" >> pass.txt
		echo "$(echo "$PAS""000" | alphabet)" >> pass.txt
	fi
done