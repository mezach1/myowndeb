#! /usr/bin/python

from types import *
from Tkinter import *

def _clear_entry_widget(event):
    try:
        widget = event.widget
        widget.delete(0, INSERT)
    except: pass
def install_keybindings(root):
    root.bind_class('Entry', '<Control-u>', _clear_entry_widget)


def make_toplevel(master, title=None, class_=None):

    if class_:
        widget = Toplevel(master, class_=class_)
    else:
        widget = Toplevel(master)
    if title:
        widget.title(title)
        widget.iconname(title)
    return widget

def set_transient(widget, master, relx=0.5, rely=0.3, expose=1):

    widget.withdraw()
    widget.transient(master)
    widget.update_idletasks()
    if master.winfo_ismapped():
        m_width = master.winfo_width()
        m_height = master.winfo_height()
        m_x = master.winfo_rootx()
        m_y = master.winfo_rooty()
    else:
        m_width = master.winfo_screenwidth()
        m_height = master.winfo_screenheight()
        m_x = m_y = 0
    w_width = widget.winfo_reqwidth()
    w_height = widget.winfo_reqheight()
    x = m_x + (m_width - w_width) * relx
    y = m_y + (m_height - w_height) * rely
    widget.geometry("+%d+%d" % (x, y))
    if expose:
        widget.deiconify()
    return widget


def make_scrollbars(parent, hbar, vbar, pack=1, class_=None, name=None,
                    takefocus=0):

    if class_:
        if name: frame = Frame(parent, class_=class_, name=name)
        else: frame = Frame(parent, class_=class_)
    else:
        if name: frame = Frame(parent, name=name)
        else: frame = Frame(parent)

    if pack:
        frame.pack(fill=BOTH, expand=1)

    corner = None
    if vbar:
        if not hbar:
            vbar = Scrollbar(frame, takefocus=takefocus)
            vbar.pack(fill=Y, side=RIGHT)
        else:
            vbarframe = Frame(frame, borderwidth=0)
            vbarframe.pack(fill=Y, side=RIGHT)
            vbar = Scrollbar(frame, name="vbar", takefocus=takefocus)
            vbar.pack(in_=vbarframe, expand=1, fill=Y, side=TOP)
            sbwidth = vbar.winfo_reqwidth()
            corner = Frame(vbarframe, width=sbwidth, height=sbwidth)
            corner.propagate(0)
            corner.pack(side=BOTTOM)
    else:
        vbar = None

    if hbar:
        hbar = Scrollbar(frame, orient=HORIZONTAL, name="hbar",
                         takefocus=takefocus)
        hbar.pack(fill=X, side=BOTTOM)
    else:
        hbar = None

    return hbar, vbar, frame


def set_scroll_commands(widget, hbar, vbar):

    if vbar:
        widget['yscrollcommand'] = (vbar, 'set')
        vbar['command'] = (widget, 'yview')

    if hbar:
        widget['xscrollcommand'] = (hbar, 'set')
        hbar['command'] = (widget, 'xview')

    widget.vbar = vbar
    widget.hbar = hbar


def make_text_box(parent, width=0, height=0, hbar=0, vbar=1,
                  fill=BOTH, expand=1, wrap=WORD, pack=1,
                  class_=None, name=None, takefocus=None):

    hbar, vbar, frame = make_scrollbars(parent, hbar, vbar, pack,
                                        class_=class_, name=name,
                                        takefocus=takefocus)

    widget = Text(frame, wrap=wrap, name="text")
    if width: widget.config(width=width)
    if height: widget.config(height=height)
    widget.pack(expand=expand, fill=fill, side=LEFT)

    set_scroll_commands(widget, hbar, vbar)

    return widget, frame


def make_list_box(parent, width=0, height=0, hbar=0, vbar=1,
                  fill=BOTH, expand=1, pack=1, class_=None, name=None,
                  takefocus=None):

    hbar, vbar, frame = make_scrollbars(parent, hbar, vbar, pack,
                                        class_=class_, name=name,
                                        takefocus=takefocus)

    widget = Listbox(frame, name="listbox")
    if width: widget.config(width=width)
    if height: widget.config(height=height)
    widget.pack(expand=expand, fill=fill, side=LEFT)

    set_scroll_commands(widget, hbar, vbar)

    return widget, frame


def make_canvas(parent, width=0, height=0, hbar=1, vbar=1,
                fill=BOTH, expand=1, pack=1, class_=None, name=None,
                takefocus=None):

    hbar, vbar, frame = make_scrollbars(parent, hbar, vbar, pack,
                                        class_=class_, name=name,
                                        takefocus=takefocus)

    widget = Canvas(frame, scrollregion=(0, 0, width, height), name="canvas")
    if width: widget.config(width=width)
    if height: widget.config(height=height)
    widget.pack(expand=expand, fill=fill, side=LEFT)

    set_scroll_commands(widget, hbar, vbar)

    return widget, frame

def make_form_entry(parent, label, borderwidth=None):

    frame = Frame(parent)
    frame.pack(fill=X)

    label = Label(frame, text=label)
    label.pack(side=LEFT)

    if borderwidth is None:
        entry = Entry(frame, relief=SUNKEN)
    else:
        entry = Entry(frame, relief=SUNKEN, borderwidth=borderwidth)
    entry.pack(side=LEFT, fill=X, expand=1)

    return entry, frame

def make_labeled_form_entry(parent, label, entrywidth=20, entryheight=1,
                            labelwidth=0, borderwidth=None,
                            takefocus=None):

    if label and label[-1] != ':': label = label + ':'

    frame = Frame(parent)

    label = Label(frame, text=label, width=labelwidth, anchor=E)
    label.pack(side=LEFT)
    if entryheight == 1:
        if borderwidth is None:
            entry = Entry(frame, relief=SUNKEN, width=entrywidth)
        else:
            entry = Entry(frame, relief=SUNKEN, width=entrywidth,
                          borderwidth=borderwidth)
        entry.pack(side=RIGHT, expand=1, fill=X)
        frame.pack(fill=X)
    else:
        entry = make_text_box(frame, entrywidth, entryheight, 1, 1,
                              takefocus=takefocus)
        frame.pack(fill=BOTH, expand=1)

    return entry, frame, label

def make_double_frame(master=None, class_=None, name=None, relief=RAISED,
                      borderwidth=1):
    if name:
        if class_: frame = Frame(master, class_=class_, name=name)
        else: frame = Frame(master, name=name)
    else:
        if class_: frame = Frame(master, class_=class_)
        else: frame = Frame(master)
    top = Frame(frame, name="topframe", relief=relief,
                borderwidth=borderwidth)
    bottom = Frame(frame, name="bottomframe")
    bottom.pack(fill=X, padx='1m', pady='1m', side=BOTTOM)
    top.pack(expand=1, fill=BOTH, padx='1m', pady='1m')
    frame.pack(expand=1, fill=BOTH)
    top = Frame(top)
    top.pack(expand=1, fill=BOTH, padx='2m', pady='2m')

    return frame, top, bottom

def make_group_frame(master, name=None, label=None, fill=Y,
                     side=None, expand=None, font=None):

    font = font or "-*-helvetica-medium-r-normal-*-*-100-*-*-*-*-*-*"
    outer = Frame(master, borderwidth=2, relief=GROOVE)
    outer.pack(expand=expand, fill=fill, side=side)
    if label:
        Label(outer, text=label, font=font, anchor=W).pack(fill=X)
    inner = Frame(master, borderwidth='1m', name=name)
    inner.pack(expand=1, fill=BOTH, in_=outer)
    inner.forget = outer.forget
    return inner

def unify_button_widths(*buttons):

    wid = 0
    for btn in buttons:
        wid = max(wid, len(btn["text"]))
    for btn in buttons:
        btn["width"] = wid


def flatten(msg):

    t = type(msg)
    if t in (ListType, TupleType):
        msg = ' '.join(map(flatten, msg))
    elif t is ClassType:
        msg = msg.__name__
    else:
        msg = str(msg)
    return msg


def boolean(s):

    if s.lower() in ('', '0', 'no', 'off', 'false'): return 0
    else: return 1


def test():

    import sys
    root = Tk()
    entry, eframe = make_form_entry(root, 'Boolean:')
    text, tframe = make_text_box(root)
    def enter(event, entry=entry, text=text):
        s = boolean(entry.get()) and '\nyes' or '\nno'
        text.insert('end', s)
    entry.bind('<Return>', enter)
    entry.insert(END, flatten(sys.argv))
    root.mainloop()


if __name__ == '__main__':
    test()
